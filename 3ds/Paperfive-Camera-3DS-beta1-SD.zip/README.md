# Paperfive Pocket Camera — native 3DS beta 1

Port of the Paperfive DSi v15 design to libctru. This is a native `.3dsx`
application, not an NDS ROM renamed to a different extension.

## Install

Extract the release ZIP onto the root of a 3DS SD card. It contains:

```
3ds/paperfive_camera/paperfive_camera.3dsx
3ds/paperfive_camera/paperfive_camera.smdh
```

Open **Paperfive Pocket Camera** in the Homebrew Launcher on a
homebrew-enabled 3DS/2DS. Do not run this file in TWiLight Menu's DS mode.
This release is not a CIA installer. The SMDH is also embedded in the 3DSX.

New JPGs are written to `/paperfive_camera_3ds/` on the SD card. The folder is
created on the first successful save. File names include a timestamp and a
collision counter. Existing DSi photos and the DSi app are not modified.

## Controls

| Control | Action |
| --- | --- |
| A / red touch button | Capture |
| X / Flip Lens tile | Inner / outer camera |
| L / R | Previous / next palette |
| Left / right | Contrast |
| Up / down | Brightness |
| Touch sliders | Brightness / contrast |
| START / Album | Open album |
| Album: left / right or PREV / NEXT | Previous / next page |
| Album: thumbnail | Select photo |
| Album: B / START / BACK | Return to camera |
| SELECT | Exit to Homebrew Launcher |

## Display and performance

- Top framebuffer: 400x240; bottom touch UI: 320x240, both double buffered.
- Camera requested at 400x240 and 30 fps using the CAM service. This camera
  mode is widescreen; it does not promise the full 640x480 sensor field of view.
- The framed picture area is 360x216, preserving the 5:3 camera output ratio.
  Saved JPGs are 400x240 and include the NINTENDO CAMERA border.
- Completed camera frames are processed while reception of the next frame
  goes into a different RAM buffer. No incomplete frame is presented.
- Non-dither filters use a lookup table rebuilt only when settings change.
- JPG encoding and writing run on a worker thread. A short red-dot blink,
  pressed shutter and success check provide capture feedback.
- The album displays the newest 128 JPGs in its folder. JPEG decoding for
  album pages is synchronous; a page change may briefly pause while reading.
- Sleep/restore stops and restarts camera capture. Buffer errors trigger a
  camera restart; startup errors leave the UI and exit button available.

**Hardware validation is still required.** The ARM executable builds and the
host checks pass, but camera access, actual frame rate, sleep/resume and SD
latency have not been measured on a physical 3DS. 30 fps is a requested camera
rate, not a measured performance claim. No stereoscopic capture is implemented.

## Build

Standard devkitPro installation with `3ds-dev`:

```
make
```

This Mac also has a verified local build path:

```
make -f Makefile.local -j4
sh tools/test.sh
```

The local path uses Wonderful GCC 16.2.0 as an ARM compiler and devkitPro's
ARMv6K hard-float CRT, libctru and newlib target libraries in `.sdk`.
It does not execute Linux toolchain binaries. Packaging tools were compiled
natively from official 3dstools sources. The `.sdk` cache is not included in
the source ZIP; use the standard devkitPro build on other machines.

Host tests check rendering bounds under AddressSanitizer, RGB565 conversion,
filter lookup equivalence, the rotated BGR framebuffer layout, UI states,
unique JPG saving and decoding/album round-trip. Generated UI previews are
actual native drawing-code renders; the top test image is a color test pattern.

## Upstream provenance

- Camera API reference: https://github.com/devkitPro/3ds-examples/tree/be2001fee08cf8ec7d3366e095e83f6f75da8942/camera/video
- 3dstools: https://github.com/devkitPro/3dstools/tree/718d6f2330dbef9dd5726573392425dcbd451677
- Official `devkitpro/devkitarm` container target-library layer:
  `sha256:3c5026e520aeec9e208399f6d0a62098d5ee4c13d8cca97cdb9adbc6bb56a1c0`.
  The downloaded layer was checked against its SHA-256 before extraction.
- JPEG encoder: Jon Olick's public-domain jo_jpeg, retained from the DSi source.
- JPEG decoder: stb_image (MIT/public domain), license retained in its header.
- libctru: https://github.com/devkitPro/libctru; devkitARM runtime:
  https://github.com/devkitPro/devkitarm-crtls.

Paperfive is an independent homebrew project, not an official Nintendo app.
